//
//  ExViewController.swift
//  collection_view
//
//  Created by Mobicip on 28/04/26.
//

import UIKit

class ExViewController: UIViewController {
    
    private var detailCollectionView: UICollectionView!
    private var daysData: [(day: String, date: String)] = []
    var selectedIndexPath: IndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        daysData = generateDays(count: 7)
        view.backgroundColor = .white
    }
    
    private func setupCollectionView() {
        detailCollectionView = UICollectionView(
            frame: .zero,
            collectionViewLayout: createCollectionViewLayout()
        )
        
        detailCollectionView.delegate = self
        detailCollectionView.dataSource = self
        detailCollectionView.backgroundColor = .white
        title = "Exercise Plan"
        
        detailCollectionView.register(DayCell.self, forCellWithReuseIdentifier: DayCell.identifier)
        detailCollectionView.register(StatCell.self, forCellWithReuseIdentifier: StatCell.identifier)
        detailCollectionView.register(ExerciseCell.self, forCellWithReuseIdentifier: ExerciseCell.identifier)
        
        view.addSubview(detailCollectionView)
        
        detailCollectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            detailCollectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            detailCollectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            detailCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            detailCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    private func createCollectionViewLayout() -> UICollectionViewCompositionalLayout {
        
        return UICollectionViewCompositionalLayout { section, _ in
            
            switch section {
                
            case 0:
                
                let item = NSCollectionLayoutItem(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(0.25),
                        heightDimension: .absolute(120)
                    )
                )
                item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 8)
                
                let group = NSCollectionLayoutGroup.horizontal(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1),
                        heightDimension: .absolute(140)
                    ),
                    subitems: [item]
                )
                group.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 0, bottom: 16, trailing: 0)
                
                let sectionLayout = NSCollectionLayoutSection(group: group)
                sectionLayout.orthogonalScrollingBehavior = .continuous
                sectionLayout.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 10, trailing: 20)
                
                return sectionLayout
                
                
            case 1:
                
                let item = NSCollectionLayoutItem(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1.0 / 4.0),
                        heightDimension: .fractionalHeight(1)
                    )
                )
                
                let group = NSCollectionLayoutGroup.horizontal(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1),
                        heightDimension: .absolute(85)
                    ),
                    subitems: [item]
                )
                
                let sectionLayout = NSCollectionLayoutSection(group: group)
                sectionLayout.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 10, trailing: 20)
                
                return sectionLayout
                
                
            case 2:
                
                let item = NSCollectionLayoutItem(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1),
                        heightDimension: .absolute(90)
                    )
                )
                item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 8, trailing: 0)
                
                let group = NSCollectionLayoutGroup.vertical(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1),
                        heightDimension: .absolute(92)
                    ),
                    subitems: [item]
                )
                
                let sectionLayout = NSCollectionLayoutSection(group: group)
                sectionLayout.interGroupSpacing = 8
                sectionLayout.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 20, trailing: 20)
                
                return sectionLayout
                
            default:
                return nil
            }
        }
    }
}

extension ExViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section{
        case 0 : return 7
        case 1 : return 4
        case 2 : return 4
        default: return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch indexPath.section {
            
        case 0:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DayCell.identifier, for: indexPath) as! DayCell
            let data = daysData[indexPath.item]
            let isSelected = indexPath == selectedIndexPath
            cell.configure(day:data.day , date: data.date, isSelected: isSelected)
            return cell
            
        case 1:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: StatCell.identifier, for: indexPath) as! StatCell
            
            let data = [("30", "Minutes"), ("3", "Set"), ("4", "Exercises"), ("3", "Level")]
            let item = data[indexPath.item]
            
            cell.configure(value: item.0, title: item.1)
            return cell
            
        case 2:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ExerciseCell.identifier, for: indexPath) as! ExerciseCell
            
            let titles = ["Push Up", "Burpees", "Tricep Dips", "Plank"]
            let subs = ["8 reps", "6 reps", "6 reps", "30 sec"]
            
            cell.configure(title: titles[indexPath.item],
                           subtitle: subs[indexPath.item],
                           image: UIImage(systemName: "figure.strengthtraining.traditional"))
            
            return cell
            
        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let previousIndexPath = selectedIndexPath
        selectedIndexPath = indexPath
        
        if let previous = previousIndexPath {
            collectionView.reloadItems(at: [previous])
        }
        
        collectionView.reloadItems(at: [indexPath])
    }
    
    func generateDays(count: Int) -> [(day: String, date: String)] {
        
        var result: [(String, String)] = []
        
        let calendar = Calendar.current
        let today = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "E d MMM"
        
        for i in 0..<count {
            if let nextDate = calendar.date(byAdding: .day, value: i, to: today) {
                
                let formattedDate = formatter.string(from: nextDate)
                result.append(("\(i + 1)", formattedDate))
            }
        }
        return result
    }
}
