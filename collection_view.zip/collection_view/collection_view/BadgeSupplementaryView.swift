//
//  BadgeSupplementaryView.swift
//  collection_view
//
//  Created by Mobicip on 04/05/26.
//
import UIKit

final class BadgeSupplementaryView: UICollectionReusableView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .green
        layer.cornerRadius = 5
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
