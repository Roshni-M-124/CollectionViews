//
//  DayCell.swift
//  collection_view
//
//  Created by Mobicip on 28/04/26.
//

import UIKit

class DayCell: UICollectionViewCell {
    
    static let identifier = "DayCell"
    
    private let titleLabel = UILabel()
    private let dayLabel = UILabel()
    private let dateLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        contentView.backgroundColor = UIColor.systemGray5
        contentView.layer.cornerRadius = 12
        
        titleLabel.text = "Day"
        titleLabel.font = .systemFont(ofSize: 14)
        titleLabel.textAlignment = .center
        
        dayLabel.font = .boldSystemFont(ofSize: 24)
        dayLabel.textAlignment = .center
        
        dateLabel.font = .systemFont(ofSize: 12)
        dateLabel.textAlignment = .center
        dateLabel.textColor = .darkGray
        
        let stack = UIStackView(arrangedSubviews: [titleLabel, dayLabel, dateLabel])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 4
        
        contentView.addSubview(stack)
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }
    
    func configure(day: String, date: String, isSelected: Bool) {
        dayLabel.text = day
        dateLabel.text = date
        
        if isSelected {
            contentView.backgroundColor = .systemRed
            titleLabel.textColor = .white
            dayLabel.textColor = .white
            dateLabel.textColor = .white
        } else {
            contentView.backgroundColor = .systemGray5
            titleLabel.textColor = .black
            dayLabel.textColor = .black
            dateLabel.textColor = .darkGray
        }
        
    }
}
