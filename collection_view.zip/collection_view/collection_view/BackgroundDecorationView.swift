//
//  BackgroundDecorationView.swift
//  collection_view
//
//  Created by Mobicip on 04/05/26.
//
import UIKit

class BackgroundDecorationView: UICollectionReusableView {
    
    static let elementKind = "background-element-kind"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .systemGray6
        layer.cornerRadius = 30
        layer.masksToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
