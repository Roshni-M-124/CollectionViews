//
//  StatCell.swift
//  collection_view
//
//  Created by Mobicip on 28/04/26.
//

import UIKit

class StatCell: UICollectionViewCell {
    
    static let identifier = "StatCell"
    
    private let valueLabel = UILabel()
    private let titleLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        valueLabel.font = .boldSystemFont(ofSize: 20)
        valueLabel.textAlignment = .center
        
        titleLabel.font = .systemFont(ofSize: 12)
        titleLabel.textAlignment = .center
        titleLabel.textColor = .darkGray
        
        let stack = UIStackView(arrangedSubviews: [valueLabel, titleLabel])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 4
        
        contentView.addSubview(stack)
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }
    
    func configure(value: String, title: String) {
        valueLabel.text = value
        titleLabel.text = title
    }
}
